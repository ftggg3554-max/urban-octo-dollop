package dev.zoneblock;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class ZoneBlock extends JavaPlugin implements Listener, TabExecutor {

    private record Anchor(UUID world, int x, int y, int z, UUID owner) {}

    // world -> chunkKey -> anchors affecting that chunk (lookup = 1 map get + tiny loop, no lag)
    private final Map<UUID, Map<Long, List<Anchor>>> index = new HashMap<>();
    private final Set<Anchor> all = new LinkedHashSet<>();
    private final Map<UUID, Set<UUID>> trust = new HashMap<>();

    private NamespacedKey key;
    private int radius;
    private Material material;
    private File dataFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        radius = Math.max(0, getConfig().getInt("radius", 5));
        Material m = Material.matchMaterial(getConfig().getString("block", "LODESTONE"));
        material = (m != null && m.isBlock()) ? m : Material.LODESTONE;
        key = new NamespacedKey(this, "zoneblock");
        dataFile = new File(getDataFolder(), "data.yml");
        load();
        Bukkit.getPluginManager().registerEvents(this, this);
        var cmd = getCommand("zoneblock");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    @Override
    public void onDisable() {
        writeSnapshot(snapshot());
    }

    // ---------------------------------------------------------------- data

    private static long ck(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xffffffffL);
    }

    private void add(Anchor a) {
        if (!all.add(a)) return;
        Map<Long, List<Anchor>> m = index.computeIfAbsent(a.world(), k -> new HashMap<>());
        for (int cx = (a.x() - radius) >> 4; cx <= (a.x() + radius) >> 4; cx++)
            for (int cz = (a.z() - radius) >> 4; cz <= (a.z() + radius) >> 4; cz++)
                m.computeIfAbsent(ck(cx, cz), k -> new ArrayList<>(2)).add(a);
    }

    private void remove(Anchor a) {
        all.remove(a);
        Map<Long, List<Anchor>> m = index.get(a.world());
        if (m == null) return;
        for (int cx = (a.x() - radius) >> 4; cx <= (a.x() + radius) >> 4; cx++)
            for (int cz = (a.z() - radius) >> 4; cz <= (a.z() + radius) >> 4; cz++) {
                List<Anchor> l = m.get(ck(cx, cz));
                if (l != null) {
                    l.remove(a);
                    if (l.isEmpty()) m.remove(ck(cx, cz));
                }
            }
    }

    private void load() {
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        for (String s : y.getStringList("anchors")) {
            try {
                String[] p = s.split(";");
                add(new Anchor(UUID.fromString(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2]),
                        Integer.parseInt(p[3]), UUID.fromString(p[4])));
            } catch (Exception ignored) {
            }
        }
        ConfigurationSection t = y.getConfigurationSection("trust");
        if (t != null) {
            for (String owner : t.getKeys(false)) {
                try {
                    Set<UUID> set = new HashSet<>();
                    for (String u : t.getStringList(owner)) set.add(UUID.fromString(u));
                    trust.put(UUID.fromString(owner), set);
                } catch (Exception ignored) {
                }
            }
        }
    }

    private YamlConfiguration snapshot() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> list = new ArrayList<>(all.size());
        for (Anchor a : all)
            list.add(a.world() + ";" + a.x() + ";" + a.y() + ";" + a.z() + ";" + a.owner());
        y.set("anchors", list);
        for (var e : trust.entrySet()) {
            List<String> u = new ArrayList<>();
            for (UUID id : e.getValue()) u.add(id.toString());
            y.set("trust." + e.getKey(), u);
        }
        return y;
    }

    private synchronized void writeSnapshot(YamlConfiguration y) {
        try {
            getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (IOException ex) {
            getLogger().warning("Could not save data: " + ex.getMessage());
        }
    }

    private void saveAsync() {
        YamlConfiguration y = snapshot();
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> writeSnapshot(y));
    }

    // ---------------------------------------------------------------- logic

    /** The anchor protecting this block (the anchor itself or anything above it), or null. */
    private Anchor guard(Block b) {
        Map<Long, List<Anchor>> m = index.get(b.getWorld().getUID());
        if (m == null) return null;
        List<Anchor> l = m.get(ck(b.getX() >> 4, b.getZ() >> 4));
        if (l == null) return null;
        for (Anchor a : l) {
            if (b.getY() >= a.y()
                    && Math.abs(a.x() - b.getX()) <= radius
                    && Math.abs(a.z() - b.getZ()) <= radius) return a;
        }
        return null;
    }

    private boolean allowed(Player p, Anchor a) {
        if (a == null) return true;
        UUID id = p.getUniqueId();
        if (id.equals(a.owner())) return true;
        if (trust.getOrDefault(a.owner(), Collections.emptySet()).contains(id)) return true;
        return p.hasPermission("zoneblock.bypass");
    }

    private void deny(Player p) {
        p.sendActionBar(Component.text("هذي المنطقة محمية", NamedTextColor.RED));
    }

    private ItemStack item() {
        ItemStack it = new ItemStack(material);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text("بلوكة الحماية", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("ضعها تحت المنطقة لحمايتها للأعلى", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(meta);
        return it;
    }

    private boolean isZoneItem(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    // ---------------------------------------------------------------- events

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlockPlaced();
        Anchor a = guard(b);
        if (!allowed(p, a)) {
            e.setCancelled(true);
            deny(p);
            return;
        }
        if (isZoneItem(e.getItemInHand())) {
            add(new Anchor(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ(), p.getUniqueId()));
            saveAsync();
            p.sendMessage(Component.text("تم تفعيل الحماية فوق هذي البلوكة", NamedTextColor.GREEN));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlock();
        Anchor a = guard(b);
        if (a == null) return;
        if (!allowed(p, a)) {
            e.setCancelled(true);
            deny(p);
            return;
        }
        if (a.x() == b.getX() && a.y() == b.getY() && a.z() == b.getZ()) {
            remove(a);
            e.setDropItems(false);
            b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), item());
            saveAsync();
            p.sendMessage(Component.text("تم إلغاء الحماية", NamedTextColor.YELLOW));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        Anchor a = guard(e.getBlock());
        if (!allowed(e.getPlayer(), a)) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        Anchor a = guard(e.getBlock());
        if (!allowed(e.getPlayer(), a)) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> guard(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> guard(b) != null);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (pistonTouchesZone(e.getBlocks(), e.getDirection())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (pistonTouchesZone(e.getBlocks(), e.getDirection())) e.setCancelled(true);
    }

    private boolean pistonTouchesZone(List<Block> blocks, BlockFace dir) {
        if (all.isEmpty()) return false;
        for (Block b : blocks) {
            if (guard(b) != null
                    || guard(b.getRelative(dir)) != null
                    || guard(b.getRelative(dir.getOppositeFace())) != null) return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- command

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage(Component.text("/zb give [لاعب] | /zb trust <لاعب> | /zb untrust <لاعب>", NamedTextColor.YELLOW));
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "give" -> {
                if (!s.hasPermission("zoneblock.give")) {
                    s.sendMessage(Component.text("ما عندك صلاحية", NamedTextColor.RED));
                    return true;
                }
                Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : (s instanceof Player pl ? pl : null);
                if (t == null) {
                    s.sendMessage(Component.text("اللاعب غير موجود", NamedTextColor.RED));
                    return true;
                }
                var left = t.getInventory().addItem(item());
                left.values().forEach(it -> t.getWorld().dropItemNaturally(t.getLocation(), it));
                s.sendMessage(Component.text("تم إعطاء البلوكة", NamedTextColor.GREEN));
            }
            case "trust", "untrust" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length < 2) {
                    s.sendMessage(Component.text("اكتب اسم اللاعب", NamedTextColor.RED));
                    return true;
                }
                OfflinePlayer t = Bukkit.getPlayerExact(a[1]);
                if (t == null) t = Bukkit.getOfflinePlayerIfCached(a[1]);
                if (t == null) {
                    s.sendMessage(Component.text("اللاعب غير موجود", NamedTextColor.RED));
                    return true;
                }
                Set<UUID> set = trust.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>());
                if (a[0].equalsIgnoreCase("trust")) set.add(t.getUniqueId());
                else set.remove(t.getUniqueId());
                saveAsync();
                s.sendMessage(Component.text("تم", NamedTextColor.GREEN));
            }
            default -> s.sendMessage(Component.text("أمر غير معروف", NamedTextColor.RED));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 1) return List.of("give", "trust", "untrust");
        return null; // player names
    }
}
